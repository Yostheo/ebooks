package main

import "./foo"

func main() {
	myBar := foo.NewBar()
	myBar.status()

}
