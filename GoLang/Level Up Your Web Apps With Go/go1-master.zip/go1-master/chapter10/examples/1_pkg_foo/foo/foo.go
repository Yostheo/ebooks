package foo

import "fmt"

func PrintFoo() {
	fmt.Println("foo")
}
