package main

import "./foo"

func main() {
	foo.PrintFoo()
}
